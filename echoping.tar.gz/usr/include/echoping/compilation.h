#define COMPILATION_OPTIONS "echoping 6.1-BETA compiled with cc on 109d2129407a (x86_64-pc-linux-musl)\n at 2019-04-18 with options:\nCFLAGS= -g -O2 -Wall\nLDFLAGS= \n\nHTTP: enabled\nICP: enabled\nOPENSSL: enabled\nGNUTLS: disabled \nSMTP: enabled\nLIBIDN: enabled\nTOS: enabled\nSCTP: enabled\nPRIORITY: enabled\n\nPlugins are searched in /usr/lib/echoping."

/* $Id$ */
